import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

df = pd.read_csv("../backend/dataset/car_rental_cbf.csv")

df.fillna("", inplace=True)

df["Mileage"] = pd.to_numeric(df["Mileage"], errors="coerce").fillna(0)
df["Engine_CC"] = pd.to_numeric(df["Engine_CC"], errors="coerce").fillna(0)

for col in ["Brand", "Fuel_Type", "Body_Type"]:
    df[col] = df[col].str.lower()

df["combined_text"] = (
    df["Brand"] + " " +
    df["Fuel_Type"] + " " +
    df["Body_Type"]
)

tfidf = TfidfVectorizer(stop_words="english")
tfidf_matrix = tfidf.fit_transform(df["combined_text"])


# ---------------------------------
# CATEGORY FILTERS
# ---------------------------------
def mileage_filter(dataframe, category):

    if category == "Low":
        return dataframe[dataframe["Mileage"] < 15]

    if category == "Medium":
        return dataframe[(dataframe["Mileage"] >= 15) & (dataframe["Mileage"] < 22)]

    if category == "High":
        return dataframe[dataframe["Mileage"] >= 22]

    return dataframe


def cc_filter(dataframe, category):

    if category == "Low Power":
        return dataframe[dataframe["Engine_CC"] < 1200]

    if category == "Medium Power":
        return dataframe[(dataframe["Engine_CC"] >= 1200) & (dataframe["Engine_CC"] < 2000)]

    if category == "High Power":
        return dataframe[dataframe["Engine_CC"] >= 2000]

    return dataframe


# ---------------------------------
# RECOMMENDER
# ---------------------------------
def recommend_cbf(prefs, top_n=5):

    user_text = " ".join([
        prefs.get("Brand", ""),
        prefs.get("Fuel_Type", ""),
        prefs.get("Body_Type", "")
    ]).lower()

    if not user_text:
        user_text = "car"

    user_vector = tfidf.transform([user_text])
    scores = cosine_similarity(user_vector, tfidf_matrix)[0]

    df_copy = df.copy()
    df_copy["similarity_score"] = scores

    df_filtered = mileage_filter(df_copy, prefs.get("Mileage"))
    df_filtered = cc_filter(df_filtered, prefs.get("Engine_CC"))

    if df_filtered.empty:
        df_filtered = df_copy

    sorted_df = df_filtered.sort_values(
        by="similarity_score",
        ascending=False
    )

    result = sorted_df.head(top_n)

    return result[[
        "Car_ID",
        "Brand",
        "Model",
        "Fuel_Type",
        "Body_Type",
        "Mileage",
        "Engine_CC",
        "similarity_score"
    ]].to_dict(orient="records")